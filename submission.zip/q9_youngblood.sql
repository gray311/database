select youngblood.RegionDescription,youngblood.FirstName,youngblood.LastName,youngblood.BirthDate
from (select Employee.FirstName,Employee.LastName,Employee.BirthDate,Region.Id,Region.RegionDescription from Employee  left outer join EmployeeTerritory  on Employee.Id = EmployeeTerritory.EmployeeId left outer join Territory on EmployeeTerritory.TerritoryId = Territory.Id  left outer join Region on Territory.RegionId = Region.Id order by Employee.BirthDate desc) as youngblood
group by youngblood.id
order by youngblood.id;