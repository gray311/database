select Id,OrderDate,lag(OrderDate,1) over(order by OrderDate),round(julianday(OrderDate)-julianDay(lag(OrderDate,1) over(order by OrderDate)),2)
from ( select * from 'Order' where CustomerId = 'BLONP')
order by OrderDate
limit 10;