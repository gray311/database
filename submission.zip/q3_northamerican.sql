select Id,ShipCountry,case when ShipCountry is not 'USA' and ShipCountry is not 'Mexico' and ShipCountry is not 'Canada' then 'OtherPlace' else 'NorthAmerica' end as IsNorthAmerica
from 'Order'
where Id >= 15445 order by Id
limit 20;