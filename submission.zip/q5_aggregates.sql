select CategoryName,count(Category.Id),round(avg(UnitPrice),2),min(UnitPrice),max(UnitPrice),sum(UnitsOnOrder) as NumProduct
from Category join Product on Product.CategoryID = Category.Id
group by Category.Id
having count(CategoryId) > 10
order by Category.Id;