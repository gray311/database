select ProductName,CompanyName,ContactName
from (select * from 'Order' join OrderDetail on 'Order'.Id = OrderId join Customer on CustomerId = Customer.Id join Product on ProductId = Product.Id where Discontinued = 1 order by OrderDate)
group by ProductId
order by ProductName;