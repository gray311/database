select CompanyName,round(count(case when ShippedDate > RequiredDate then 1 else NULL end)*100/round(count('Order'.Id)),2) as percentage
from 'Order' left outer join Shipper on 'Order'.ShipVia = Shipper.Id
group by Shipper.Id
order by percentage desc;