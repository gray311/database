select group_concat(ProductName,', ')
from 'Order' left outer join OrderDetail on 'Order'.Id = OrderDetail.OrderId left outer join Product on OrderDetail.ProductId = Product.Id left outer join Customer on 'Order'.CustomerId = Customer.Id
where CompanyName = 'Queen Cozinha' and OrderDate like '2014-12-25%';